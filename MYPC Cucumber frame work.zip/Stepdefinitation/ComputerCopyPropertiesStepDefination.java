package Stepdefinitation;

import org.testng.Assert;

import adminpage.ComputerLocationProperties;
import automation.pages.utils.ConfigReader;
import hookclass.HookClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ComputerCopyPropertiesStepDefination {

    private ComputerLocationProperties computerLocationProperties;
    private ConfigReader config;

    private void initComputerLocationProperties() {

        if (config == null) {
            config = new ConfigReader();
        }

        if (computerLocationProperties == null) {
            computerLocationProperties =
                    new ComputerLocationProperties(HookClass.driver);
        }
    }



    @And("I open Computer Tools")
    public void i_open_Computer_tools() {

        initComputerLocationProperties();

        computerLocationProperties.ClickComputerTools();
    }


    

    @And("I click Computer Copy Properties")
    public void i_click_Computer_copy_properties() {

        initComputerLocationProperties();

        computerLocationProperties.clickCopyProperties();
    }


    // =====================================================
    // SOURCE
    // =====================================================

    @When("I select the configured computer as the source")
    public void i_select_the_configured_computer_as_the_source() {

        initComputerLocationProperties();

        System.out.println(
            "Computer from Cucumber config = [" + config.getComputerName() + "]"
        );

        computerLocationProperties.SelectSource(
            config.getComputerName()
        );
    }


    

    @And("I select the configured location as the target")
    public void i_select_the_configured_location_as_the_target() {

        initComputerLocationProperties();

        computerLocationProperties.selectLocation(config.getLocation());
        
    }


    // =====================================================
    // COMPUTER COPY OPTIONS
    // =====================================================

    @And("I enable the computer tag option")
    public void i_enable_the_computer_tag_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableTags();

        Assert.assertTrue(
                computerLocationProperties.TagsisSelected(),
                "Computer tag option is not selected"
        );
    }


    @And("I enable the second computer tag option")
    public void i_enable_the_second_computer_tag_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableTags1();
    }


    @And("I enable the computer location option")
    public void i_enable_the_computer_location_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableLocation();
    }


    @And("I enable the computer default duration option")
    public void i_enable_the_computer_default_duration_option() {

        initComputerLocationProperties();

        computerLocationProperties.enabledfaulttime();
    }


    @And("I enable the allowed booking method option")
    public void i_enable_the_allowed_booking_method_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableallowedBookingMethod();
    }


    @And("I enable the computer preparation time option")
    public void i_enable_the_computer_preparation_time_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableprepartime();
    }


    @And("I enable the computer check-in option")
    public void i_enable_the_computer_check_in_option() {

        initComputerLocationProperties();

        computerLocationProperties.enablecheckinsetting();
    }


    // =====================================================
    // WARNING TIMES
    // =====================================================

    @And("I enable computer level one warning time")
    public void i_enable_computer_level_one_warning_time() {

        initComputerLocationProperties();

        computerLocationProperties.enablelevel1time();
    }


    @And("I enable computer level two warning time")
    public void i_enable_computer_level_two_warning_time() {

        initComputerLocationProperties();

        computerLocationProperties.enablelevel2time();
    }


    @And("I enable computer level three warning time")
    public void i_enable_computer_level_three_warning_time() {

        initComputerLocationProperties();

        computerLocationProperties.enablelevel3time();
    }


    // =====================================================
    // OTHER COMPUTER OPTIONS
    // =====================================================

    @And("I enable the computer logging level option")
    public void i_enable_the_computer_logging_level_option() {

        initComputerLocationProperties();

        computerLocationProperties.enablelogginglevel();
    }


    @And("I enable the computer welcome message option")
    public void i_enable_the_computer_welcome_message_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableWlecomeMessage();
    }


    @And("I enable the computer AUP message option")
    public void i_enable_the_computer_aup_message_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableaupMessage();
    }


    @And("I enable the computer automatic reboot option")
    public void i_enable_the_computer_automatic_reboot_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableAllowautoRebot();
    }


    @And("I enable the computer automatic shutdown option")
    public void i_enable_the_computer_automatic_shutdown_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableallowAutoShutdown();
    }


    // =====================================================
    // INACTIVITY TIMEOUT
    // =====================================================

    @And("I enable the computer inactivity timeout option")
    public void i_enable_the_computer_inactivity_timeout_option() {

        initComputerLocationProperties();

        computerLocationProperties.enableincativitytimenout();
    }


    // =====================================================
    // LOCK TIMEOUT
    // =====================================================

    @And("I enable the computer lock timeout option")
    public void i_enable_the_computer_lock_timeout_option() {

        initComputerLocationProperties();

        computerLocationProperties.enablelocktimeout();
    }


    // =====================================================
    // COPY
    // =====================================================

    @When("I copy the computer properties")
    public void i_copy_the_computer_properties() {

        initComputerLocationProperties();

        computerLocationProperties.ClickCopy();
    }


    // =====================================================
    // VALIDATION
    // =====================================================

    @Then("the copy operation should be displayed")
    public void the_copy_operation_should_be_displayed() {
        initComputerLocationProperties();

        Assert.assertTrue(
            computerLocationProperties.isDisplayed(),
            "Copy is not displayed"
        );
    }
    }
