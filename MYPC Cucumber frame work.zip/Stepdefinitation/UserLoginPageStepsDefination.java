package Stepdefinitation;


	import org.testng.Assert;

	import adminpage.UserLoginPage;
	import automation.pages.utils.ConfigReader;
	import hookclass.HookClass;
	import io.cucumber.java.en.And;
	import io.cucumber.java.en.Then;
	import io.cucumber.java.en.When;

	public class UserLoginPageStepsDefination {

	    private UserLoginPage userLoginPage;
	    private ConfigReader config;

	    private void initUserLoginPage() {

	        if (config == null) {
	            config = new ConfigReader();
	        }

	        if (userLoginPage == null) {
	            userLoginPage = new UserLoginPage(HookClass.driver);
	        }
	    }


	    @When("I select Remember Me")
	    public void i_select_remember_me() {

	        initUserLoginPage();

	        userLoginPage.enableCheckBox();
	    }


	    @Then("Remember Me should be selected")
	    public void remember_me_should_be_selected() {

	        initUserLoginPage();

	        Assert.assertTrue(
	                userLoginPage.isRemembermeSelected(),
	                "Remember Me checkbox is not selected"
	        );
	    }


	    @Then("language option should be displayed")
	    public void language_option_should_be_displayed() {

	        initUserLoginPage();

	        Assert.assertTrue(
	                userLoginPage.languageisDisplayed(),
	                "Language option is not displayed"
	        );
	    }


	    @And("I enable Large Text")
	    public void i_enable_large_text() {

	        initUserLoginPage();

	        userLoginPage.enabLargeText();
	    }
	}

