package Stepdefinitation;

import org.testng.Assert;

import adminpage.Desk_Tags;
import automation.pages.utils.ConfigReader;
import hookclass.HookClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class DeskTagsSteps {

    private Desk_Tags deskTags;
    private ConfigReader config;

    private void init() {

        if (config == null) {
            config = new ConfigReader();
        }

        if (deskTags == null) {
            deskTags = new Desk_Tags(HookClass.driver);
        }
    }

    @And("I open Desk Tools")
    public void i_open_desk_tools() {

        init();

        deskTags.ClickTools();
        deskTags.ClickDesk();
    }

    @And("I navigate to Desk Tags")
    public void i_navigate_to_desk_tags() {

        init();

        deskTags.ClickTags();
    }

    @And("I click Add New for Desk Tags")
    public void i_click_add_new_for_desk_tags() {

        init();

        deskTags.ClickAddNew();
    }

    @And("I enter desk tag")
    public void i_enter_desk_tag() {

        init();

        String tagName = config.getDeskTagName();

        deskTags.enterDeskTags(tagName);
    }

    @And("I click Add for Desk Tags")
    public void i_click_add_for_desk_tags() {

        init();

        deskTags.clickAdd();
    }

    @Then("the Desk Tags submit button should be displayed")
    public void the_desk_tags_submit_button_should_be_displayed() {

        init();

        Assert.assertTrue(
                deskTags.isDisplayedSubmit(),
                "Submit button is not displayed"
        );
    }
}
