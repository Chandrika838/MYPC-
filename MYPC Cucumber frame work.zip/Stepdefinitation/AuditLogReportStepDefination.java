package Stepdefinitation;

import reports.AuditLogReport;
import automation.pages.utils.ConfigReader;
import hookclass.HookClass;

import io.cucumber.java.en.And;

public class AuditLogReportStepDefination {

    private AuditLogReport auditLogReport;
    private ConfigReader config;

    private void initAuditLogReport() {

        if (config == null) {
            config = new ConfigReader();
        }

        if (auditLogReport == null) {
            auditLogReport =
                    new AuditLogReport(HookClass.driver);
        }
    }


    @And("I open Reports")
    public void i_open_reports() {

        initAuditLogReport();

        auditLogReport.ClickReport();
    }


    @And("I open Audit Log Reports")
    public void i_open_audit_log_reports() {

        initAuditLogReport();

        auditLogReport.ClickAuidtLog();
    }


    @And("I select the Audit Log category")
    public void i_select_the_audit_log_category() {

        initAuditLogReport();

        auditLogReport.SelectCateory(
                config.getCateory()
        );
    }


    @And("I select the Audit Log period")
    public void i_select_the_audit_log_period() {

        initAuditLogReport();

        auditLogReport.SelectPeriod(
                config.getperiod()
        );
    }


    @And("I click the Pie Chart option")
    public void i_click_the_pie_chart_option() {

        initAuditLogReport();

        auditLogReport.ClickPie();
    }


    @And("I click the Chart option")
    public void i_click_the_chart_option() {

        initAuditLogReport();

        auditLogReport.Clickchart();
    }


    @And("I click Show Details")
    public void i_click_show_details() {

        initAuditLogReport();

        auditLogReport.ClickDetails();
    }


    @And("I export the Audit Log report to CSV")
    public void i_export_the_audit_log_report_to_csv() {

        initAuditLogReport();

        auditLogReport.ClickExportCSV();
    }
}