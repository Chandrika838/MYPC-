Feature: Location Copy Properties

Scenario: Verify Location Copy Properties functionality

    Given I open the application
    When I enter valid email
    And I enter valid password
    And I click the login button

    And I am on the Location Copy Properties page

    When I select the source location
    And I enable the Target option
    And I enable the Parent Location option
    And I enable the Time Zone option
    And I enable the Working Hours option
    And I click the Location Copy Button

    Then the location properties should be copied