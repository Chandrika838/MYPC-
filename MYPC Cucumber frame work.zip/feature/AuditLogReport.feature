Feature: Audit Log Report functionality

  Scenario: Verify Audit Log Report

    Given I open the application

    When I enter valid email
    And I enter valid password
    And I click the login button

    And I open Reports
    And I open Audit Log Reports

    And I select the Audit Log category
    And I select the Audit Log period

    And I click the Pie Chart option
    And I click the Chart option

    And I click Show Details
    And I export the Audit Log report to CSV