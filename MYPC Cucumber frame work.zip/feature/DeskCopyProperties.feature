Feature:Verify Desk Copy Properties 
Scenario:


Given I open the application
When I enter valid email
When I enter valid password
When I enable high contrast
Then high contrast should be enabled
When I click the login button
Then the logged in username should be displayed
Then the logged in username should not be empty
And I open the Admin menu
And I open Tools
And I navigate to Desk Copy Properties
And I select the desk copy location
And I enable desk tags
And I enable desk location setting
And I enable desk default duration
And I enable desk preparation time
And I enable desk check in setting
And I enable desk check in tags
And I click the desk Copy button