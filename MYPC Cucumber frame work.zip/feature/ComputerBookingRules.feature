Feature: Computer Booking Rules

  Scenario: Configure computer booking rules

    Given I open the application

    When I enter valid email
    And I enter valid password
    And I enable high contrast
    Then high contrast should be enabled

    When I click the login button
    Then the logged in username should be displayed
    And the logged in username should not be empty

    And I open the Admin menu
    And I open Tools
    And I open Computer Tools

    When I open Computer Booking Rules

    And I select the Automation Tags computer tag

    And I enable computer access
    And I enable the computer access toggle

    And I enable computer maximum bookings per month
    And I enter the computer maximum bookings per month value

    And I enable computer maximum booking duration
    And I enter the computer maximum booking duration value

    And I enable computer bookings per day
    And I enter the computer bookings per day value

    And I enable computer maximum time allowed per day
    And I enter the computer maximum time allowed per day value

    And I enable computer maximum period to book in advance
    And I enter the computer maximum advance booking period value

    And I enable computer booking extension
    And I enable the booking extension toggle

    And I enable automatic extension
    And I enable the automatic extension toggle

    And I enable maximum extension time
    And I enable the maximum extension time toggle

    And I enable number of extensions
    And I enable the number of extensions toggle

    When I submit the computer booking rules