Feature: User Login functionality

  Scenario: Verify valid administrator login with login preferences

    Given I open the application

    When I enter valid email
    And I enter valid password

    And I select Remember Me
    Then Remember Me should be selected

    And language option should be displayed

    And I enable Large Text

    When I click the login button

    Then the logged in username should be displayed
    And the logged in username should not be empty