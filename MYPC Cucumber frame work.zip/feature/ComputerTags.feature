Feature:ComputerTags Functionality 

Scenario:Verify ComputerTags

    Given I open the application
    When I enter valid email
    When I enter valid password
    When I enable high contrast
    Then high contrast should be enabled
    When I click the login button
    Then the logged in username should be displayed
    Then the logged in username should not be empty
    
And I open the Admin menu 
And I open Tools
And I open Computer Tools
And I open Computer Tags
And I click Add New in Computer Tags
And I enter the Computer Tags 
And I Submit the new Computer tag 
Then I submit the new computer tag should be displayed 




